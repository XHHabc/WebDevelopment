import com.lms.mapper.BorrowRecordDAO;
import com.lms.mapper.BorrowRecordFilter;
import com.lms.pojo.BorrowRecord;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BorrowRecordDAOTest {

    @Test
    public void testAddBorrowRecord() {
        BorrowRecordDAO dao = new BorrowRecordDAO();

        // 创建一个合适的 BorrowRecord 对象
        BorrowRecord borrowRecord = new BorrowRecord();
        borrowRecord.setUserID(1);
        borrowRecord.setBookID(2);
        borrowRecord.setBorrowDate(new Date());  // 设置借书日期为当前日期
        borrowRecord.setReturnDate(new Date());  // 设置还书日期为当前日期

        boolean added = dao.add(borrowRecord);
        System.out.println(added);
    }

    @Test
    public void testUpdateBorrowRecord() {
        BorrowRecordDAO dao = new BorrowRecordDAO();

        // 创建一个合适的 BorrowRecord 对象
        BorrowRecord borrowRecord = new BorrowRecord();

        borrowRecord.setRecordID(5);
        borrowRecord.setUserID(1);
        borrowRecord.setBookID(2);
        borrowRecord.setBorrowDate(new Date());  // 设置借书日期为当前日期
        borrowRecord.setReturnDate(new Date());  // 设置还书日期为当前日期
        borrowRecord.setActualReturnDate(new Date());  // 设置实际返回日期为 null（可选）

        boolean updated = dao.update(borrowRecord);
        System.out.println(updated);
    }

    @Test
    public void testUpdateActualReturnDatedBorrowRecord() {
        BorrowRecordDAO dao = new BorrowRecordDAO();

        // 创建一个合适的 BorrowRecord 对象
        BorrowRecord borrowRecord = new BorrowRecord();

        borrowRecord.setRecordID(5);
        try {
            borrowRecord.setActualReturnDate(
                    new SimpleDateFormat("yyyy-MM-dd").parse("2023-06-01"));
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        boolean updateActualReturnDated = dao.updateActualReturnDate(borrowRecord);
        System.out.println(updateActualReturnDated);
    }

    @Test
    public void testFindBorrowRecord() {
        BorrowRecordDAO dao = new BorrowRecordDAO();
        List<BorrowRecord> list = dao.find(1, 5);
        System.out.println(list);

        int number = dao.getTotalPages(5);
        System.out.println(number);
    }

    @Test
    public void testFindByFilterBorrowRecord() {
        BorrowRecordDAO dao = new BorrowRecordDAO();
        BorrowRecordFilter filter = new BorrowRecordFilter();
        filter.setBookID(2);
        try {
            filter.setActualReturnDateEnd(new SimpleDateFormat("yyyy-MM-dd").parse("2023-06-01"));
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        List<BorrowRecord> list = dao.findByFilter(1, 5, filter);
        System.out.println(list);
        System.out.println(list.get(0).getActualReturnDate());

        int number = dao.getTotalPages(5, filter);
        System.out.println(number);
    }
}
