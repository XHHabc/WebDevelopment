import com.lms.mapper.BorrowRecordFilter;
import org.junit.Test;

import java.util.*;

public class BorrowRecordFilterTest {
    @Test
    public void BorrowRecordFilter() {
        BorrowRecordFilter filter = new BorrowRecordFilter();
        System.out.println(filter.generateFilterCondition());

        Object[] objects = filter.getParameters();
        System.out.println(Arrays.toString(objects));
    }

}
