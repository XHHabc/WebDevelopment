import com.lms.mapper.UserDAO;
import org.junit.Test;
import com.lms.pojo.User;

public class UserDAOTest {
    @Test
    public void UserDAO() {
        UserDAO userDAO = new UserDAO();
        User user = new User(0, "admin", "123456", "");
        boolean res1 = userDAO.register(user);
        System.out.println(res1);

        boolean res2 = userDAO.login(user);
        System.out.println(res2);

        boolean res3 = userDAO.resetPassword(user);
        System.out.println(res3);

        System.out.println(userDAO.findNameById(1));
    }

    @Test
    public void User() {
        User user = new User(1, "user1", "12345678", "232@qq.com");
        System.out.println(user.isValid());


    }
}
