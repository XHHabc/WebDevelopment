package com.lms.utils;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VerifyUtil {
    public static boolean verifyEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        // 邮箱正则表达式
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    /**
     * 传入String的值，判断是否合法,合法则Integer.parseInt，不合法则返回defaultValue
     *
     * @param parameter
     * @param defaultValue
     * @return
     */
    public static int VerifyInteger(String parameter, int defaultValue) {
        if (parameter == null || parameter.equals("")) {
            return defaultValue;
        } else {
            return Integer.parseInt(parameter);
        }
    }

    public static int verifyInteger(String parameter) {
        try {
            return Integer.parseInt(parameter);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /**
     * 传入String的值，判断是否合法,合法则返回，不合法则返回null
     */
    public static String VerifyString(String parameter) {
        if (parameter == null || "".equals(parameter)) {
            return null;
        } else {
            return parameter;
        }
    }
//    public static Boolean VerifyListIsNull(List<?> list){
//        for (Object o : list) {
//            if (o == null || "".equals(o)){
//                return true;
//            }else{
//                return
//            }
//        }
}
