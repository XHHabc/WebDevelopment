package com.lms.mapper;

import com.lms.pojo.Category;
import com.lms.pojo.RealBook;
import com.lms.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {
    List<User> selectAll();

    int delete(@Param("userId") Integer userId);

    int insert(User user);

    int modify(User user);
}
