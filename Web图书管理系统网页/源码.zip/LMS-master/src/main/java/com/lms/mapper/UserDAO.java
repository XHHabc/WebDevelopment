package com.lms.mapper;

import com.lms.pojo.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {

    /**
     * 注册用户
     *
     * @param user 新增的用户
     * @return 是否添加成功
     */
    public boolean register(User user) {
        SQLConnect sqlConnect = null;
        boolean ret = false;
        String sql = "INSERT INTO User (Username, Password, Email) \n" +
                "VALUES(?, ?, ?)";
        try {
            sqlConnect = new SQLConnect();
            PreparedStatement ps = sqlConnect.prepareStatement(sql);
            ps.setString(1, user.getUserName());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getEmail());

            int rs = ps.executeUpdate();
            ret = (rs > 0);
        } catch (Exception e) {
//            e.printStackTrace();
        } finally {
            if (sqlConnect != null)
                sqlConnect.close();
        }

        return ret;
    }

    /**
     * 用户登录验证
     *
     * @param user 登录的用户
     * @return 是否成功
     */
    public boolean login(User user) {
        SQLConnect sqlConnect = null;
        boolean ret = false;
        String sql = "select COUNT(*) from User where username = ? and password = ?";
        try {
            sqlConnect = new SQLConnect();
            PreparedStatement ps = sqlConnect.prepareStatement(sql);
            ps.setString(1, user.getUserName());
            ps.setString(2, user.getPassword());

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                ret = rs.getInt(1) == 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (sqlConnect != null)
                sqlConnect.close();
        }
        return ret;
    }

    /**
     * 重置密码：
     * 通过用户名和邮箱重置密码
     *
     * @param user
     * @return 是否成功
     */
    public boolean resetPassword(User user) {
        SQLConnect sqlConnect = null;
        boolean ret = false;
        String sql = "update User set password = ? where username = ? and email = ?";
        try {
            sqlConnect = new SQLConnect();
            PreparedStatement ps = sqlConnect.prepareStatement(sql);
            ps.setString(1, user.getPassword());
            ps.setString(2, user.getUserName());
            ps.setString(3, user.getEmail());

            int rs = ps.executeUpdate();
            if (rs > 0) {
                ret = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (sqlConnect != null)
                sqlConnect.close();
        }
        return ret;
    }

    public  String findNameById(Integer id) {
        String ret = null;
        SQLConnect sqlConnect = null;
        String sql = "select Username from User where UserID = ?";
        try {
            sqlConnect = new SQLConnect();
            PreparedStatement ps = sqlConnect.prepareStatement(sql);
            ps.setObject(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                ret = rs.getString("Username");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (sqlConnect != null)
                sqlConnect.close();
        }

        return ret;
    }
}