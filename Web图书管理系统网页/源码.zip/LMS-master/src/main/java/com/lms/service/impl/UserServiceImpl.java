package com.lms.service.impl;

import com.github.pagehelper.PageHelper;
import com.lms.mapper.BookMapper;
import com.lms.mapper.CategoryMapper;
import com.lms.mapper.UserMapper;
import com.lms.pojo.Book;
import com.lms.pojo.Category;
import com.lms.pojo.User;
import com.lms.service.UserService;
import com.lms.utils.SqlSessionUtil;
import com.lms.utils.VerifyUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;
import java.util.Map;

public class UserServiceImpl implements UserService {
    @Override
    public List<User> selectAllBook(int page) {
        UserMapper mapper = null;
        List<User> UserList = null;
        SqlSession sqlSession = null;
        try {
            //每次都获取一个新的对象
            sqlSession = SqlSessionUtil.openSession();
            mapper = sqlSession.getMapper(UserMapper.class);
            //       service调用mapper(dao)层
            //验证数据
            if (page <= 0) {
                page = 1;
            }
            PageHelper.startPage(page, 5);
            UserList = mapper.selectAll();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return UserList;
    }

    @Override
    public int deleteOneUser(int userId) {
        UserMapper mapper = null;
        int count = 0;
        SqlSession sqlSession = null;
        try {
            sqlSession = SqlSessionUtil.openSession();
            mapper = sqlSession.getMapper(UserMapper.class);
            count = mapper.delete(userId);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            SqlSessionUtil.openSession().rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public int insertOneUser(User user) {
        int count = 0;
        SqlSession sqlSession = SqlSessionUtil.openSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        //验证数据
        // 校验title
        if (VerifyUtil.VerifyString(user.getUserName()) == null) {
            throw new RuntimeException("UserName 不合法");
        }
// 校验author
        if (VerifyUtil.VerifyString(user.getPassword()) == null) {
            throw new RuntimeException("Password 不合法");
        }
        if (!VerifyUtil.verifyEmail(user.getEmail())) {
            throw new RuntimeException("Email 不合法");
        }
        try {
            count = mapper.insert(user);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            SqlSessionUtil.openSession().rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public int modifyOneUser(User user) {
        UserMapper mapper = null;
        int count = 0;
        SqlSession sqlSession = null;
        sqlSession = SqlSessionUtil.openSession();
        mapper = sqlSession.getMapper(UserMapper.class);
        try {
            count = mapper.modify(user);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            sqlSession.rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }
}
