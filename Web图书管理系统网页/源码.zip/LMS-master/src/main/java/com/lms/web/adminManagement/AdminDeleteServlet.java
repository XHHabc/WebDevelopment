package com.lms.web.adminManagement;

import com.lms.service.AdminService;
import com.lms.service.impl.AdminServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminDeleteServlet", value = "/AdminDeleteServlet")
public class AdminDeleteServlet extends HttpServlet {
    AdminService adminService = new AdminServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String adminID = request.getParameter("AdminID");
        try {
            int count = adminService.deleteOneAdmin(Integer.parseInt(adminID));
            if (count == 1) {
                request.getRequestDispatcher("/AdminServlet?page=1").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "删除管理员失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
