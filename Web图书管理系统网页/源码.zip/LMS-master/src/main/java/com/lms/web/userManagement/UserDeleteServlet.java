package com.lms.web.userManagement;

import com.lms.service.UserService;
import com.lms.service.impl.UserServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "UserDeleteServlet", value = "/UserDeleteServlet")
public class UserDeleteServlet extends HttpServlet {
    //调用service层
    UserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userID = Integer.parseInt(request.getParameter("UserID"));
        try {
            int count = userService.deleteOneUser(userID);
            if (count == 1) {
                request.getRequestDispatcher("/UserServlet?page=1").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "删除用户失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
