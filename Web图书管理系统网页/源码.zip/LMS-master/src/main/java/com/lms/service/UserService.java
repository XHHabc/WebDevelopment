package com.lms.service;

import com.lms.pojo.User;

import java.util.List;

public interface UserService {
    List<User> selectAllBook(int page);

    int deleteOneUser(int userId);

    int insertOneUser(User user);

    int modifyOneUser(User user);

}
