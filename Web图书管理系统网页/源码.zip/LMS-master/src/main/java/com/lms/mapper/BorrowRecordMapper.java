package com.lms.mapper;

public class BorrowRecordMapper {
}
