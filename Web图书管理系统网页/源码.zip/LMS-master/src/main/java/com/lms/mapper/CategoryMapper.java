package com.lms.mapper;

import com.lms.pojo.Category;
import org.apache.ibatis.annotations.Param;

import java.util.*;

public interface CategoryMapper {
    /**
     * 查询所有图书类型
     *
     * @return
     */
    List<Category> selectAll();

    /**
     * 插入单个数据
     */
    int insert(Category category);

    /**
     * 删除单个数据
     */
    int deleteOne(@Param("categoryId") Integer categoryId);

    int modifyOne(Category category);

    int updateCategoryToNull(@Param("categoryId") Integer categoryId);
}
