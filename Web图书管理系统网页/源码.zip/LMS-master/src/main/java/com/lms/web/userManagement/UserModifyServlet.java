package com.lms.web.userManagement;

import com.lms.pojo.Category;
import com.lms.pojo.User;
import com.lms.service.UserService;
import com.lms.service.impl.UserServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "UserModifyServlet", value = "/UserModify")
public class UserModifyServlet extends HttpServlet {
    //调用service层
    UserService userService = new UserServiceImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = Integer.parseInt(request.getParameter("userId"));
        String userName = request.getParameter("userName");
        String newPassword = request.getParameter("newPassword");
        String email = request.getParameter("userEmail");
        //经过js验证后的两次密码一致
        try {
            int count = userService.modifyOneUser(new User(userId, userName, newPassword, email));
            if (count == 1) {
                response.sendRedirect(request.getContextPath() + "/UserServlet?page=1");
            }
        } catch (Exception e) {
            request.setAttribute("error", "修改用户失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
