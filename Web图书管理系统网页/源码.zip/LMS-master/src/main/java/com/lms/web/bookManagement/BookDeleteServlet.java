package com.lms.web.bookManagement;

import com.lms.service.BookService;
import com.lms.service.impl.BookServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "BookDeleteServlet", value = "/BookDeleteServlet")
public class BookDeleteServlet extends HttpServlet {
    BookService bookService = new BookServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int bookId = Integer.parseInt(request.getParameter("bookId"));
        try {
            int count = bookService.deleteOneBook(bookId);
            if (count == 1) {
                request.getRequestDispatcher("/BookServlet?page=1").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "图书删除失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }


    }
}
