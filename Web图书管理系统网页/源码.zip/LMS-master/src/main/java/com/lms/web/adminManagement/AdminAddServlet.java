package com.lms.web.adminManagement;

import com.lms.pojo.Admin;
import com.lms.pojo.User;
import com.lms.service.AdminService;
import com.lms.service.impl.AdminServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminAddServlet", value = "/adminAdd")
public class AdminAddServlet extends HttpServlet {
    AdminService adminService = new AdminServiceImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String adminName = request.getParameter("adminName");
        String adminPassword = request.getParameter("adminPassword");

        try {
            int count = adminService.insertOneAdmin(new Admin(adminName, adminPassword));
            if (count == 1) {
                response.sendRedirect(request.getContextPath() + "/AdminServlet?page=1");
            }
        } catch (Exception e) {
            request.setAttribute("error", "新增管理员失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
