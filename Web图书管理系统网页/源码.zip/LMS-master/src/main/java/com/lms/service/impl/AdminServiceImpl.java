package com.lms.service.impl;

import com.github.pagehelper.PageHelper;
import com.lms.mapper.AdminMapper;
import com.lms.mapper.UserMapper;
import com.lms.pojo.Admin;
import com.lms.pojo.User;
import com.lms.service.AdminService;
import com.lms.utils.SqlSessionUtil;
import com.lms.utils.VerifyUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class AdminServiceImpl implements AdminService {

    @Override
    public List<Admin> selectAllAdmin(int page) {
        AdminMapper mapper = null;
        List<Admin> UserList = null;
        SqlSession sqlSession = null;
        try {
            //每次都获取一个新的对象
            sqlSession = SqlSessionUtil.openSession();
            mapper = sqlSession.getMapper(AdminMapper.class);
            //       service调用mapper(dao)层
            //验证数据
            if (page <= 0) {
                page = 1;
            }
            PageHelper.startPage(page, 5);
            UserList = mapper.selectAll();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return UserList;
    }

    @Override
    public int deleteOneAdmin(int adminId) {
        AdminMapper mapper = null;
        int count = 0;
        SqlSession sqlSession = null;
        try {
            sqlSession = SqlSessionUtil.openSession();
            mapper = sqlSession.getMapper(AdminMapper.class);
            count = mapper.delete(adminId);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            SqlSessionUtil.openSession().rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public int insertOneAdmin(Admin admin) {
        int count = 0;
        SqlSession sqlSession = SqlSessionUtil.openSession();
        AdminMapper mapper = sqlSession.getMapper(AdminMapper.class);
        //验证数据
        if (VerifyUtil.VerifyString(admin.getAdminName()) == null) {
            throw new RuntimeException("AdminName 不合法");
        }
        if (VerifyUtil.VerifyString(admin.getAdminPassword()) == null) {
            throw new RuntimeException("AdminPassword 不合法");
        }
        try {
            count = mapper.insert(admin);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            SqlSessionUtil.openSession().rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public int modifyOneAdmin(Admin admin) {
        AdminMapper mapper = null;
        int count = 0;
        SqlSession sqlSession = null;
        sqlSession = SqlSessionUtil.openSession();
        mapper = sqlSession.getMapper(AdminMapper.class);
        try {
            count = mapper.modify(admin);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            sqlSession.rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }
}
