package com.lms.service;

import com.lms.pojo.Category;

import java.util.*;

public interface CategoryService {
    //查询所有Category
    List<Category> selectAllCategory(int page);

    //删除categoryId的数据
    int deleteOneCategory(Integer categoryId);

    //插入一条category
    int insertOneCategory(Category category);

    int modifyOneCategory(Category category);

    void closeSqlSession();
}
