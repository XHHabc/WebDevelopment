package com.lms.web.userManagement;

import com.github.pagehelper.PageInfo;
import com.lms.pojo.User;
import com.lms.service.UserService;
import com.lms.service.impl.UserServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.util.*;
import java.io.IOException;

@WebServlet(name = "UserServlet", value = "/UserServlet")
public class UserServlet extends HttpServlet {
    //  本该是用依赖注入的方式,表现层调service层
    UserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");  //解决编码问题
        List<User> userList = null;

        String page = request.getParameter("page");

        if (page == null) {
            userList = userService.selectAllBook(1);
            ;
        } else {
            userList = userService.selectAllBook(Integer.parseInt(page));
        }
        try {
            PageInfo<User> pageInfo = new PageInfo<>(userList);
            //传入pageInfo封装的对象
            request.setAttribute("pageInfo", pageInfo);
            request.getRequestDispatcher("showAllUser.jsp?page=" + page).forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "查询所有用户失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }

    }
}
