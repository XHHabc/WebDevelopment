package com.lms.pojo;

import java.util.regex.Pattern;

public class User {
    private Integer UserID;
    private String UserName;
    private String Password;
    private String Email;

    public User(String userName, String password, String email) {
        UserName = userName;
        Password = password;
        Email = email;
    }

    @Override
    public String toString() {
        return "User{" +
                "UserID=" + UserID +
                ", UserName='" + UserName + '\'' +
                ", Password='" + Password + '\'' +
                ", Email='" + Email + '\'' +
                '}';
    }

    public User() {
    }

    public User(Integer userID, String userName, String password, String email) {
        UserID = userID;
        UserName = userName;
        Password = password;
        Email = email;
    }

    /**
     * 验证账号格式
     * @return 是否正确
     * @apiNote 只对不为null的成员进行判断
     */
    public boolean isValid() {
        if (UserID != null && UserID <= 0) {
            return false;
        }
        //用户名4~16字符，不能包括特殊字符、中文..（字母+数组）
        if (UserName != null && !Pattern.matches("^[a-zA-Z0-9]{4,16}$", UserName)) {
            return false;
        }
        //密码8~20字符（不能包含除字母、数组、符号以外的字符）
        if (Password != null && !Pattern.matches("^[a-zA-Z0-9!@#$%^&*()-_=+\\|\\[{\\]};:'\",.<>/?]{8,20}$", Password)) {
            return false;
        }
        //邮箱符合邮箱格式
        if (Email != null && !Pattern.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$", Email)) {
            return false;
        }
        return true;
    }

    public Integer getUserID() {
        return UserID;
    }

    public void setUserID(Integer userID) {
        UserID = userID;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
