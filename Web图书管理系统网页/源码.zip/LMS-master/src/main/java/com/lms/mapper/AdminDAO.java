package com.lms.mapper;

import com.lms.pojo.Admin;
import com.lms.pojo.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminDAO {


    public boolean register(Admin admin) {
        SQLConnect sqlConnect = null;
        boolean ret = false;
        String sql = "INSERT INTO Admin (AdminName, AdminPassword) \n" +
                "VALUES(?, ?)";
        try {
            sqlConnect = new SQLConnect();
            PreparedStatement ps = sqlConnect.prepareStatement(sql);
            ps.setString(1, admin.getAdminName());
            ps.setString(2, admin.getAdminPassword());
            int rs = ps.executeUpdate();
            ret = (rs > 0);
        } catch (Exception e) {
//            e.printStackTrace();
        } finally {
            if (sqlConnect != null)
                sqlConnect.close();
        }

        return ret;
    }

    /**
     * 登录验证
     */
    public boolean login(Admin admin) {
        SQLConnect sqlConnect = null;
        boolean ret = false;
        String sql = "select COUNT(*) from Admin where AdminName = ? and AdminPassword = ?";
        try {
            sqlConnect = new SQLConnect();
            PreparedStatement ps = sqlConnect.prepareStatement(sql);
            ps.setString(1, admin.getAdminName());
            ps.setString(2, admin.getAdminPassword());

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                ret = rs.getInt(1) == 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (sqlConnect != null)
                sqlConnect.close();
        }
        return ret;
    }

}