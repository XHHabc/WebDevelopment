package com.lms.service;

import com.lms.pojo.Book;
import com.lms.pojo.RealBook;

import java.util.List;

public interface BookService {
    //查询所有图书信息
    List<Book> selectAllBook(int page);

    //TODO 插入一条记录
    int insertOneBook(RealBook realBook);

    //TODO 动态查询
    public List<Book> searchBook(String parameterBookId, String parameterTitle, String author, String publisher, String parameterCategoryID, String parameterMax, String parameterMin);

    int deleteOneBook(Integer bookId);

    int modifyOneBook(RealBook realBook);

    void closeSqlSession();
}

