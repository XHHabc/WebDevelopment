package com.lms.web.bookManagement;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

import com.lms.pojo.Book;
import com.lms.pojo.RealBook;
import com.lms.service.BookService;
import com.lms.service.impl.*;
@WebServlet(name = "bookadd", value = "/bookadd")
public class bookAddServlet extends HttpServlet {
    BookService bookService = new BookServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");  //解决编码问题

        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String publisher = request.getParameter("publisher");
        Integer categoryID = Integer.parseInt(request.getParameter("categoryID"));
        String stockQuantity = request.getParameter("stockQuantity");
        /**         测试数据:能拿到 √
         *         System.out.println(request.getMethod());
         *         System.out.println(title+" tile");
         *         System.out.println(author+" author");
         *         System.out.println(publisher+" publisher");
         *         System.out.println(categoryID+" categoryID");
         *         System.out.println(stockQuantity+" stockQuantity");
         */
        try {
            bookService.insertOneBook(new RealBook(title, author, publisher, categoryID, Integer.parseInt(stockQuantity)));
            request.getRequestDispatcher("/BookServlet?page=1").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "图书添加失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
            //重定向到
        }
    }
}
