package com.lms.web.borrowRecordManagement;

import com.lms.mapper.BorrowRecordDAO;
import com.lms.pojo.BorrowRecord;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(
        name = "DeleteBorrowRecordServlet",
        value = "/deleteBorrowRecord"
)
public class DeleteBorrowRecordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取表单提交的数据
        int recordID = Integer.parseInt(request.getParameter("recordID"));
        BorrowRecordDAO dao = new BorrowRecordDAO();
        BorrowRecord del = new BorrowRecord();
        del.setRecordID(recordID);
        boolean isDel = dao.delete(del);
        if (isDel) {
            // 重定向到借阅记录列表页面
            response.sendRedirect("borrowRecord.jsp");
        } else {
            request.setAttribute("error", "删除借阅失败");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

}
