package com.lms.utils;

import com.lms.mapper.CategoryMapper;
import com.lms.pojo.Category;
import org.apache.ibatis.session.SqlSession;

import java.util.*;

//获取category表中的数据
public class GetCategoryUtil {
    public static List<Category> getCategoryList() {
        SqlSession sqlSession = SqlSessionUtil.openSession();
        CategoryMapper mapper = sqlSession.getMapper(CategoryMapper.class);
        List<Category> categoryList = mapper.selectAll();
        return categoryList;
    }
}
