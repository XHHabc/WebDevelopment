package com.lms.service.impl;

import com.github.pagehelper.PageHelper;
import com.lms.mapper.BookMapper;
import com.lms.mapper.CategoryMapper;
import com.lms.pojo.Category;
import com.lms.service.CategoryService;
import com.lms.utils.SqlSessionUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class CategoryServiceImpl implements CategoryService {
    @Override
    public List<Category> selectAllCategory(int page) {
        CategoryMapper mapper = null;
        List<Category> categoryList = null;
        SqlSession sqlSession = null;
        sqlSession = SqlSessionUtil.openSession();
        sqlSession.clearCache();
        mapper = sqlSession.getMapper(CategoryMapper.class);
        if (page <= 0) {
            page = 1;
        }
        PageHelper.startPage(page, 5);
        categoryList = mapper.selectAll();
        SqlSessionUtil.close(sqlSession);
        return categoryList;
    }
    @Override
    public int deleteOneCategory(Integer categoryId) {
        CategoryMapper mapper = null;
        List<Category> categoryList = null;
        int count = 0;
        SqlSession sqlSession = null;
        try {
            sqlSession = SqlSessionUtil.openSession();
            mapper = sqlSession.getMapper(CategoryMapper.class);
            mapper.updateCategoryToNull(categoryId);
            count = mapper.deleteOne(categoryId);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            SqlSessionUtil.openSession().rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public int insertOneCategory(Category category) {
        CategoryMapper mapper = null;
        List<Category> categoryList = null;
        int count = 0;
        // 每次查询都获取新的 SqlSession
        SqlSession sqlSession = SqlSessionUtil.openSession();
        try {
            mapper = sqlSession.getMapper(CategoryMapper.class);
            if (category.getCategoryName() == null || category.getCategoryName().trim().isEmpty()
                    || category.getCategoryName().length() > 30) {
                throw new RuntimeException("图书类型名称 不合法");
            } else {
                count = mapper.insert(category);
                SqlSessionUtil.openSession().commit();
            }
        } catch (Exception e) {
            sqlSession.rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public int modifyOneCategory(Category category) {
        CategoryMapper mapper = null;
        int count = 0;
        SqlSession sqlSession = null;
        sqlSession = SqlSessionUtil.openSession();
        mapper = sqlSession.getMapper(CategoryMapper.class);
        try {
            if (category.getCategoryName() == null || category.getCategoryName().trim().isEmpty()
                    || category.getCategoryName().length() > 30) {
                throw new RuntimeException("图书类型名称 不合法");
            } else {
                count = mapper.modifyOne(category);
                SqlSessionUtil.openSession().commit();
            }
        } catch (Exception e) {
            sqlSession.rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public void closeSqlSession() {
        SqlSessionUtil.openSession().close();
    }
}
