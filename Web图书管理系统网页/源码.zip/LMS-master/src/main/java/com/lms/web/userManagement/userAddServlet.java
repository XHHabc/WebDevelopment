package com.lms.web.userManagement;

import com.lms.pojo.Category;
import com.lms.pojo.User;
import com.lms.service.UserService;
import com.lms.service.impl.UserServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "userAddServlet", value = "/userAdd")
public class userAddServlet extends HttpServlet {
    //调用service层
    UserService userService = new UserServiceImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userName = request.getParameter("userName");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        try {
            int count = userService.insertOneUser(new User(userName, password, email));
            if (count == 1) {
                response.sendRedirect(request.getContextPath() + "/UserServlet?page=1");
            }
        } catch (Exception e) {
            request.setAttribute("error", "新增用户失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
