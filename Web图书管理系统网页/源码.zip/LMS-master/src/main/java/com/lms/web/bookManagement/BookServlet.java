package com.lms.web.bookManagement;

import com.github.pagehelper.PageInfo;
import com.lms.pojo.Book;
import com.lms.service.BookService;
import com.lms.service.impl.BookServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "BookServlet", value = "/BookServlet")
public class BookServlet extends HttpServlet {
//  本该是用依赖注入的方式,表现层调service层
BookService bookService = new BookServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");  //解决编码问题
        String page = request.getParameter("page");
        List<Book> bookList = null;

        if (page == null) {
            bookList = bookService.selectAllBook(1);
        } else {
            bookList = bookService.selectAllBook(Integer.parseInt(page));
        }
        try {
            PageInfo<Book> pageInfo = new PageInfo<>(bookList);
            //传入pageInfo封装的对象
            request.setAttribute("pageInfo", pageInfo);
            request.getRequestDispatcher("showAllBook.jsp?page=" + page).forward(request, response);
        }catch (Exception e) {
            request.setAttribute("error", "查询所有图书失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
            //重定向到
        }
    }
}
