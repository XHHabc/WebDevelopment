package com.lms.service;

import com.lms.pojo.Admin;
import com.lms.pojo.User;

import java.util.List;

public interface AdminService {
    List<Admin> selectAllAdmin(int page);

    int deleteOneAdmin(int adminId);

    int insertOneAdmin(Admin admin);

    int modifyOneAdmin(Admin admin);
}
