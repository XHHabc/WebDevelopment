package com.lms.utils;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;

/**
 * Mybatis工具类
 * 所有工具方法都是静态,为了方便调用
 */
public class SqlSessionUtil {
    private  static SqlSessionFactory sqlSessionFactory;

    private SqlSessionUtil() {

    }

    //注意：sqlSessionFactory应该对应一个environment,一个environment通常是一共数据库
    //所有有必要放在类加载时候初始化一次！！！
    static {
        try {
            SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
            sqlSessionFactory = sqlSessionFactoryBuilder.build(Resources.getResourceAsStream("mybatis-config.xml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //全局的,服务器级别的,一个服务器当中定义一个即可
    // 为什么把SqLSession对象放到ThreadLocal当中呢? 为了保证一个线程对应一个SgLSession(一个线程一个事务)
    private static ThreadLocal<SqlSession> local=new ThreadLocal<>();

    //TODO 获取会话对象 保证获取的sqlsession是同一个,第一个则获取一个
    public static SqlSession openSession(){
        SqlSession sqlSession = local.get();
        if (sqlSession==null){
            sqlSession = sqlSessionFactory.openSession();
            //只一次绑定,将sqlSession对象绑定在当前线程
            local.set(sqlSession);

        }
        return sqlSession;
    }
    //TODO 从当前线程移除sqlSession对象
    public static void close(SqlSession sqlSession){
        if (sqlSession!=null){
            sqlSession.close();
            // 注意移除SqLSession对象和当前线程的绑定关系。
            // 因为Tomcat服务器支持线程池。也就是说: 用过的线程对象t1，可能下一次还会使用这个t1线程。
            local.remove();
        }
    }
}
