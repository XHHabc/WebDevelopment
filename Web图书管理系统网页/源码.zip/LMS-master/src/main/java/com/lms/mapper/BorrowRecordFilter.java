package com.lms.mapper;

import java.util.*;

/**
 * 借阅记录的筛选器
 * 成员方法generateFilterCondition返回sql的准备查询语言
 * 成员方法getParameters返回查询语言对应的参数
 */
public class BorrowRecordFilter {
    private Integer recordID;
    private Integer userID;
    private Integer bookID;
    private Date borrowDateStart;
    private Date borrowDateEnd;
    private Date returnDateStart;
    private Date returnDateEnd;
    private Date actualReturnDateStart;
    private Date actualReturnDateEnd;

    public BorrowRecordFilter() {
    }


    public String generateFilterCondition() {
        List<String> conditions = new ArrayList<>();
        List<Object> parameters = new ArrayList<>();

        if (recordID != null) {
            conditions.add("RecordID = ?");
            parameters.add(recordID);
        }

        if (userID != null) {
            conditions.add("UserID = ?");
            parameters.add(userID);
        }

        if (bookID != null) {
            conditions.add("BookID = ?");
            parameters.add(bookID);
        }

        if (borrowDateStart != null) {
            conditions.add("BorrowDate >= ?");
            parameters.add(borrowDateStart);
        }

        if (borrowDateEnd != null) {
            conditions.add("BorrowDate <= ?");
            parameters.add(borrowDateEnd);
        }

        if (returnDateStart != null) {
            conditions.add("ReturnDate >= ?");
            parameters.add(returnDateStart);
        }

        if (returnDateEnd != null) {
            conditions.add("ReturnDate <= ?");
            parameters.add(returnDateEnd);
        }

        if (actualReturnDateStart != null) {
            conditions.add("ActualReturnDate >= ?");
            parameters.add(actualReturnDateStart);
        }

        if (actualReturnDateEnd != null) {
            conditions.add("ActualReturnDate <= ?");
            parameters.add(actualReturnDateEnd);
        }

        String condition = String.join(" AND ", conditions);

        if (condition.isEmpty()) {
            condition = " 1=1 ";
        }
        return condition;
    }

    public Object[] getParameters() {
        List<Object> parameters = new ArrayList<>();

        if (recordID != null) {
            parameters.add(recordID);
        }

        if (userID != null) {
            parameters.add(userID);
        }

        if (bookID != null) {
            parameters.add(bookID);
        }

        if (borrowDateStart != null) {
            parameters.add(borrowDateStart);
        }

        if (borrowDateEnd != null) {
            parameters.add(borrowDateEnd);
        }

        if (returnDateStart != null) {
            parameters.add(returnDateStart);
        }

        if (returnDateEnd != null) {
            parameters.add(returnDateEnd);
        }

        if (actualReturnDateStart != null) {
            parameters.add(actualReturnDateStart);
        }

        if (actualReturnDateEnd != null) {
            parameters.add(actualReturnDateEnd);
        }

        return parameters.toArray();
    }


    public Integer getRecordID() {
        return recordID;
    }

    public void setRecordID(Integer recordID) {
        this.recordID = recordID;
    }

    public Integer getUserID() {
        return userID;
    }

    public void setUserID(Integer userID) {
        this.userID = userID;
    }

    public Integer getBookID() {
        return bookID;
    }

    public void setBookID(Integer bookID) {
        this.bookID = bookID;
    }

    public Date getBorrowDateStart() {
        return borrowDateStart;
    }

    public void setBorrowDateStart(Date borrowDateStart) {
        this.borrowDateStart = borrowDateStart;
    }

    public Date getBorrowDateEnd() {
        return borrowDateEnd;
    }

    public void setBorrowDateEnd(Date borrowDateEnd) {
        this.borrowDateEnd = borrowDateEnd;
    }

    public Date getReturnDateStart() {
        return returnDateStart;
    }

    public void setReturnDateStart(Date returnDateStart) {
        this.returnDateStart = returnDateStart;
    }

    public Date getReturnDateEnd() {
        return returnDateEnd;
    }

    public void setReturnDateEnd(Date returnDateEnd) {
        this.returnDateEnd = returnDateEnd;
    }

    public Date getActualReturnDateStart() {
        return actualReturnDateStart;
    }

    public void setActualReturnDateStart(Date actualReturnDateStart) {
        this.actualReturnDateStart = actualReturnDateStart;
    }

    public Date getActualReturnDateEnd() {
        return actualReturnDateEnd;
    }

    public void setActualReturnDateEnd(Date actualReturnDateEnd) {
        this.actualReturnDateEnd = actualReturnDateEnd;
    }
}
