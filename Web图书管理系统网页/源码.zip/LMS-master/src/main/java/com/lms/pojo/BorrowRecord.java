package com.lms.pojo;

import java.util.Date;

public class BorrowRecord {
    private int recordID;
    private int userID;
    private int bookID;
    private Date borrowDate;
    private Date returnDate;
    private Date actualReturnDate;

    /*
    -   RecordID：借阅记录的唯一标识符，自增长整数类型。
    -   UserID：借阅记录对应的用户ID，外键关联到User表的UserID字段。
    -   BookID：借阅记录对应的图书ID，外键关联到Book表的BookID字段。
    -   BorrowDate：借阅日期，不能为空。
    -   ReturnDate：应归还日期，不能为空。
    -   ActualReturnDate：实际归还日期。
    */
    @Override
    public String toString() {
        return "BorrowRecord{" +
                "recordID=" + recordID +
                ", userID=" + userID +
                ", BookID=" + bookID +
                ", borrowDate='" + borrowDate + '\'' +
                ", returnDate='" + returnDate + '\'' +
                ", actualReturnDate='" + actualReturnDate + '\'' +
                '}';
    }

    public BorrowRecord() {
    }

    public BorrowRecord(int recordID, int userID, int bookID, Date borrowDate, Date returnDate, Date actualReturnDate) {
        this.recordID = recordID;
        this.userID = userID;
        this.bookID = bookID;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
        this.actualReturnDate = actualReturnDate;
    }

    public int getRecordID() {
        return recordID;
    }

    public void setRecordID(int recordID) {
        this.recordID = recordID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public Date getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(Date borrowDate) {
        this.borrowDate = borrowDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public Date getActualReturnDate() {
        return actualReturnDate;
    }

    public void setActualReturnDate(Date actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
    }
}
