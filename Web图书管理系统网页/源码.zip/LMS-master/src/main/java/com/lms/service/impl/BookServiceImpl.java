package com.lms.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lms.mapper.BookMapper;
import com.lms.mapper.CategoryMapper;
import com.lms.pojo.Book;
import com.lms.pojo.Category;
import com.lms.pojo.RealBook;
import com.lms.service.BookService;
import com.lms.utils.SqlSessionUtil;
import com.lms.utils.VerifyUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class BookServiceImpl implements BookService {
    //TODO 查询所有的书,按分页
    @Override
    public List<Book> selectAllBook(int page) {
        BookMapper mapper = null;
        List<Book> bookList = null;
        SqlSession sqlSession = null;
        try {
            //每次都获取一个新的对象
            sqlSession = SqlSessionUtil.openSession();
            mapper = sqlSession.getMapper(BookMapper.class);
            //       service调用mapper(dao)层
            //验证数据
            if (page <= 0) {
                page = 1;
            }
            PageHelper.startPage(page, 5);
            bookList = mapper.selectAll();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return bookList;
    }

    //TODO 插入一条记录
    @Override
    public int insertOneBook(RealBook realbook) {
        int count = 0;
        SqlSession sqlSession = SqlSessionUtil.openSession();
        BookMapper mapper = sqlSession.getMapper(BookMapper.class);
        //验证数据
        // 校验title
        if (VerifyUtil.VerifyString(realbook.getTitle()) == null) {
            throw new RuntimeException("title 不合法");
        }
        // 校验author
        if (VerifyUtil.VerifyString(realbook.getAuthor()) == null) {
            throw new RuntimeException("Author 不合法");
        }
        // 校验categoryID
//        if (realbook.getCategoryID() == null) {
//            throw new RuntimeException("Category 不合法");
//        }
        // 校验stockQuantity
        if (realbook.getStockQuantity() == null || realbook.getStockQuantity() < 0) {
            throw new RuntimeException("Stock quantity 不合法");
        }
        try {
            count = mapper.insert(realbook);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            SqlSessionUtil.openSession().rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    //TODO 动态查询
    @Override
    public List<Book> searchBook(String parameterBookId, String parameterTitle, String parameterAuthor, String parameterPublisher, String parameterCategoryID, String parameterMax, String parameterMin) {
        BookMapper mapper = null;
        SqlSession sqlSession = null;
        sqlSession = SqlSessionUtil.openSession();
        sqlSession.clearCache();
        List<Book> bookList = null;

        mapper = sqlSession.getMapper(BookMapper.class);
        int bookId = 0;
        int min;
        int max;
        int categoryId = 0;
        //处理bookId
        bookId = VerifyUtil.VerifyInteger(parameterBookId, 0);
//            if (parameterBookId == null || parameterBookId.equals("")) {
//                bookId = 0;
//            } else {
//                bookId = Integer.parseInt(parameterBookId);
//            }
        min = VerifyUtil.VerifyInteger(parameterMin, 1);
        max = VerifyUtil.VerifyInteger(parameterMax, 1000);
        parameterCategoryID = VerifyUtil.VerifyString(parameterCategoryID);
        categoryId = Integer.parseInt(parameterCategoryID);
        try {
            bookList = mapper.selectByMultiConditionWithTrim(bookId, parameterTitle, parameterAuthor, parameterPublisher, categoryId, min, max);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return bookList;
    }

    @Override
    public int deleteOneBook(Integer bookId) {
        BookMapper mapper = null;
        int count = 0;
        SqlSession sqlSession = SqlSessionUtil.openSession();
        mapper = SqlSessionUtil.openSession().getMapper(BookMapper.class);
        try {
            count = mapper.delete(bookId);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            SqlSessionUtil.openSession().rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public int modifyOneBook(RealBook realBook) {
        BookMapper mapper = null;
        int count = 0;
        SqlSession sqlSession = SqlSessionUtil.openSession();
        try {
            mapper = SqlSessionUtil.openSession().getMapper(BookMapper.class);
            count = mapper.modify(realBook);
            SqlSessionUtil.openSession().commit();
        } catch (Exception e) {
            SqlSessionUtil.openSession().rollback();
            e.printStackTrace();
        } finally {
            SqlSessionUtil.close(sqlSession);
        }
        return count;
    }

    @Override
    public void closeSqlSession() {
        SqlSessionUtil.openSession().close();
    }
}
