package com.lms.mapper;

import com.lms.pojo.Book;
import com.lms.pojo.RealBook;
import org.apache.ibatis.annotations.Param;

import java.util.*;
//TODO dao层
public interface BookMapper {
    /**
     * 查询所有图书信息,并放入list集合中
     * @return
     */
    List<Book> selectAll();
    /**
     * 添加图书
     *
     * @param realbook 对应表中book类的字段
     * @return
     */
    int insert(RealBook realbook);

    /**
     * 根据条件查询
     *
     * @param bookID     图书id
     * @param title      图书名
     * @param author     作者
     * @param publisher  出版社
     * @param categoryid 图书类型id
     * @param minStock   最小库存
     * @param maxStock   最大库存
     * @return
     */
    List<Book> selectByMultiConditionWithTrim(@Param("bookID") Integer bookID, @Param("title") String title, @Param("author") String author, @Param("publisher") String publisher, @Param("categoryID") Integer categoryid, @Param("minStock") Integer minStock, @Param("maxStock") Integer maxStock);

    int delete(@Param("bookId") Integer id);

    //图书修改
    int modify(RealBook realbook);

    String selectByBookId(@Param("bookId") Integer bookId);
}
