package com.lms.web.bookManagement;

import com.github.pagehelper.PageInfo;
import com.lms.mapper.BookMapper;
import com.lms.pojo.Book;
import com.lms.service.BookService;
import com.lms.service.impl.BookServiceImpl;
import com.lms.utils.SqlSessionUtil;
import com.lms.utils.VerifyUtil;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "searchBookServlet", value = "/searchBookServlet")
public class searchBookServlet extends HttpServlet {
    BookService bookService = new BookServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String BookId = request.getParameter("bookID");
        String title = request.getParameter("title");
        String publisher = request.getParameter("publisher");
        String author = request.getParameter("author");
        String categoryID = request.getParameter("categoryID");
        String min = request.getParameter("min");
        String max = request.getParameter("max");
        /**
         * bookid =1
         * title =三体
         * publisher =广州出版社
         * author =张顺飞
         * categoryid =8
         */
        //如果用户只点击了全选，没有填写其他
        try {
            if (BookId.equals("") && title.equals("") && publisher.equals("") && author.equals("") && Integer.parseInt(categoryID) == 0 && min.equals("") && max.equals("")) {
                response.sendRedirect(request.getContextPath() + "/BookServlet");
            } else {
                List<Book> bookList = bookService.searchBook(BookId, title, author, publisher, categoryID, max, min);
                PageInfo<Book> pageInfo = new PageInfo<>(bookList);
                System.out.println(pageInfo.getList());
                request.setAttribute("pageInfo", pageInfo);
                request.setAttribute("searchPage", "123");   //设置参数为搜索,区分与主页的区别
                request.getRequestDispatcher("/showAllBook.jsp?page=1").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "查询条件图书失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }


    }
}
