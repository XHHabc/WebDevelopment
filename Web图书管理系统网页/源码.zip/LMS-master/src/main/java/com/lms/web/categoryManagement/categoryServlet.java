package com.lms.web.categoryManagement;

import com.github.pagehelper.PageInfo;
import com.lms.pojo.Book;
import com.lms.pojo.Category;
import com.lms.service.BookService;
import com.lms.service.CategoryService;
import com.lms.service.impl.BookServiceImpl;
import com.lms.service.impl.CategoryServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "categoryServlet", value = "/categoryServlet")
public class categoryServlet extends HttpServlet {
    //调用service层
    CategoryService categoryService = new CategoryServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");  //解决编码问题
        String page = request.getParameter("page");

        List<Category> categoryList = null;
        try {
            //调用service层的方法
            if (page == null) {
                categoryList = categoryService.selectAllCategory(1);
            } else {
                categoryList = categoryService.selectAllCategory(Integer.parseInt(page));
            }
            PageInfo<Category> pageInfo = new PageInfo<>(categoryList);
            //传入pageInfo封装的对象
            request.setAttribute("pageInfo", pageInfo);
            request.getRequestDispatcher("showAllCategory.jsp?page=1").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "查询图书失败,请联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
