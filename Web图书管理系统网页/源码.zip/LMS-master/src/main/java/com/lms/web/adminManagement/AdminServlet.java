package com.lms.web.adminManagement;

import com.github.pagehelper.PageInfo;
import com.lms.pojo.Admin;
import com.lms.pojo.User;
import com.lms.service.AdminService;
import com.lms.service.UserService;
import com.lms.service.impl.AdminServiceImpl;
import com.lms.service.impl.UserServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdminServlet", value = "/AdminServlet")
public class AdminServlet extends HttpServlet {
    AdminService adminService = new AdminServiceImpl();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");  //解决编码问题
        List<Admin> adminList = null;
        String page = request.getParameter("page");
        if (page == null) {
            adminList = adminService.selectAllAdmin(1);
        } else {
            adminList = adminService.selectAllAdmin(Integer.parseInt(page));
        }
        try {
            PageInfo<Admin> pageInfo = new PageInfo<>(adminList);
            //传入pageInfo封装的对象
            request.setAttribute("pageInfo", pageInfo);
            request.getRequestDispatcher("showAllAdmin.jsp?page=" + page).forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "查询所有管理员失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
