package com.lms.pojo;

public class RealBook {
    private Integer bookID;
    private String title;
    private String author;
    private String publisher;
    private Integer categoryID;
    private Integer stockQuantity;

    public RealBook() {
    }

    public RealBook(Integer bookID, String title, String author, String publisher, Integer categoryID, Integer stockQuantity) {
        this.bookID = bookID;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.categoryID = categoryID;
        this.stockQuantity = stockQuantity;
    }
    public RealBook(String title, String author, String publisher, Integer categoryID, Integer stockQuantity) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.categoryID = categoryID;
        this.stockQuantity = stockQuantity;
    }

    public Integer getBookID() {
        return bookID;
    }

    public void setBookID(Integer bookID) {
        this.bookID = bookID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public Integer getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(Integer categoryID) {
        this.categoryID = categoryID;
    }

    public Integer getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(Integer stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    @Override
    public String toString() {
        return "RealBook{" +
                "bookID=" + bookID +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", publisher='" + publisher + '\'' +
                ", categoryID=" + categoryID +
                ", stockQuantity=" + stockQuantity +
                '}';
    }
}
