package com.lms.web.categoryManagement;

import com.lms.service.CategoryService;
import com.lms.service.impl.CategoryServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "CategoryDeleteServlet", value = "/CategoryDeleteServlet")
public class CategoryDeleteServlet extends HttpServlet {
    //调用service层
    CategoryService categoryService = new CategoryServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int bookId = Integer.parseInt(request.getParameter("categoryId"));
        try {
            int count = categoryService.deleteOneCategory(bookId);
            if (count == 1) {
                request.getRequestDispatcher("/categoryServlet?page=1").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "删除分类失败,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }

    }
}
