package com.lms.mapper;

import com.lms.pojo.Admin;
import com.lms.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AdminMapper {
    List<Admin> selectAll();

    int delete(@Param("adminID") Integer adminID);

    int insert(Admin admin);

    int modify(Admin admin);
}
