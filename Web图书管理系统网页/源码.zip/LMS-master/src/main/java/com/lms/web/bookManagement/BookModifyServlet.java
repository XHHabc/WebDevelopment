package com.lms.web.bookManagement;

import com.lms.pojo.RealBook;
import com.lms.service.BookService;
import com.lms.service.impl.BookServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "BookModifyServlet", value = "/bookModify")
public class BookModifyServlet extends HttpServlet {
    BookService bookService = new BookServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 32
         * 四体
         * 刘德华
         * 广州出版社
         * null
         * 2
         */
        int bookId = Integer.parseInt(request.getParameter("bookId"));
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String publisher = request.getParameter("publisher");
        int categoryID = Integer.parseInt(request.getParameter("categoryID"));
        int stockQuantity = Integer.parseInt(request.getParameter("stockQuantity"));
        try {
            RealBook realBook = new RealBook(bookId, title, author, publisher, categoryID, stockQuantity);
            int count = bookService.modifyOneBook(realBook);
            if (count == 1) {
                request.getRequestDispatcher("/BookServlet?page=1").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "图书修改,请重试或联系管理员");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
